﻿function message()
{
	alert('bonjour');
}