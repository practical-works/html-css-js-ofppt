﻿var i = 9;
var chaine = "Bonjour";

document.write("Un entier : " + i + "<br />");
document.write("Un chaine : " + chaine);