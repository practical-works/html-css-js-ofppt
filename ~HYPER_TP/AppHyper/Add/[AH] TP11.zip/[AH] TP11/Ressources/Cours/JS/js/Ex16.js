﻿function continuer()
{
	var etat = confirm("Voulez-vous contineur ?")
	
	if (etat == true) alert("Vous avez choisi \"OK\"");
	else alert("Vous avez choisi \"Annuler\"");
}