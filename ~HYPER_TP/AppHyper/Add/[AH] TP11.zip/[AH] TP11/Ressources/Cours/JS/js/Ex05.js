﻿function afficher()
{
	document.write("Texte");
}