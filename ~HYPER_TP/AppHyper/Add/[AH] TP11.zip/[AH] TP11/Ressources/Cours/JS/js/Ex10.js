﻿var i = 1;

function afficher()
{
	document.write("<p> Paragraphe " + i + "</p>");
	i++;
}