﻿function afficher()
{
	table = document.createElement('table');
	table.style.border = '1px solid blue';
	table.style.borderCollapse = 'collapse';
	
	for(i = 1; i <= 10; i++)
	{
		tr = document.createElement('tr');
		
		for(j = 1; j <= 10; j++)
		{
			td = document.createElement('td');
			td.style.border = '1px solid blue';
			td.style.width = '50px';
			
			// Texte
			// text = document.createTextNode(i * j);
			// td.appendChild(text);
			
			// Button
			button = document.createElement('input');
			button.type = 'button';
			button.value = i * j;
			button.style.width = '40px';
			td.appendChild(button);
			
			tr.appendChild(td);
		}
		
		table.appendChild(tr);
	}
	
	document.body.appendChild(table);
}