﻿$(document).ready(function(){
	li_CouleurInitiale = $('li').css('color');
	
	$('li').mouseover(function(){
		$(this).css('color', 'red');
		$(this).css('cursor', 'text');
	})	
	
	$('li').mouseout(function(){
		$(this).css('color', li_CouleurInitiale);
	})

	$('#ajouter').click(function(){
		var valeur = $('#nombre')[0].value;

		// M1 : jQuery
		$('ul:first()').append($('<li></li>').text(valeur));
		
		// M2 : HTML
		// $('ul:first()').append('<li>' + valeur + '</li>');
		
		// M3 : DOM
		// var element = document.createElement('li');
		// element.innerHTML = valeur;
		// $('ul:first()').append(element);
	})
})