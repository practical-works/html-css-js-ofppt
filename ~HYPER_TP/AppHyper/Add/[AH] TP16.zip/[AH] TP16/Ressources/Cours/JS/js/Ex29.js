﻿$(document).ready(function(){
	li_CouleurInitiale = $('li').css('color');
	
	$('ul').on('mouseover', 'li', function(){
		$(this).css('color', 'red');
		$(this).css('cursor', 'text');
	});
	
	$('ul').on('mouseout', 'li', function(){
		$(this).css('color', li_CouleurInitiale);
	});

	$('#ajouterAuDebut, #ajouterALaFin').click(function(){
		ajouter(this);
	})
	
	function ajouter(button)
	{
		var valeur = $('#nombre')[0].value,
			emplacement = (button.id == 'ajouterAuDebut') ? 'prepend' : 'append';
		
		// M1 : jQuery
		expression = "$('ul:first()')." + emplacement + "($('<li></li>').text(valeur))";
		
		// M2 : HTML
		// expression = "$('ul:first()')." + emplacement + "('<li>' + valeur + '</li>')";
		
		// M3 : DOM
		// var element = document.createElement('li');
		// element.innerHTML = valeur;
		// expression = "$('ul:first()')." + emplacement +"(element)";
		
		eval(expression);
	}
})