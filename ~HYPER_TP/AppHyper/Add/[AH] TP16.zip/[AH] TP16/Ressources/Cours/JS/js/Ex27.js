﻿$(document).ready(function(){
	$('input[type="button"]').click(function(){
		$('input[type="text"]')[0].value = 'Button : ' + this.value;
	})
	
	$('#afficher').click(function(){
		$('p').show();
	})
	
	$('#masquer').click(function(){
		$('p').hide();
	})	
	
	$('#afficherMasquer').click(function(){
		$('p').toggle(1000);
	})	
})