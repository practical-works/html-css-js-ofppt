﻿var t = new Array(3);

t[0] = "ahmed";
t[1] = "mohamed";
t[2] = "fatima";

for(i = 0; i < t.length; i++)
{
	document.write(t[i] + "<br />");
}

document.write("<hr />");

for(i = 0; i < t.length; i++)
{
	document.write(t[i].toUpperCase() + "<br />");
}