﻿function afficher()
{
	document.write("Texte <br />");
}