﻿var a = 5, b = 2;

document.write("<h1>Arithmétique</h1>");

document.write("a = " + a);
document.write("<br />");

document.write("b = " + b);
document.write("<br />");

document.write("a + b = " + (a + b));
document.write("<br />");

document.write("a - b = " + (a - b));
document.write("<br />");

document.write("a * b = " + (a * b));
document.write("<br />");

document.write("a % b = " + (a % b));
document.write("<br />");

document.write("a / b (division réelle) = " + (a / b));
document.write("<br />");

document.write("a / b (division entière) = " + (parseInt(a / b)));
document.write("<br />");