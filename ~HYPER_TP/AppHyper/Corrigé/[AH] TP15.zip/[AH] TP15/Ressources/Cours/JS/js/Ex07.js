﻿function afficher()
{
	document.write("<p style = 'color:red'>Un paragraphe en rouge contenant <u>un texte souligné</u></p>");
}